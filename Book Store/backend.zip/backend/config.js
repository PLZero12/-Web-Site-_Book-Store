export const PORT = 5555;

export const mongoDBURL = 'mongodb+srv://autautloha:PL111203Loha@note-app.s8svl.mongodb.net/?retryWrites=true&w=majority&appName=Note-App'